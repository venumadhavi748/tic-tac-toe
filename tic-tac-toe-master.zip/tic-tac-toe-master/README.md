# Hi, I'm Mukesh Kumar! 👋

  # About Project
## Tic Tac Toe
In this website I created a game Tic Tac Toe using `Reactjs` and some `npm packages`.
  


## Feedback

If you have any feedback, please reach out to us at ak9991927952@gmail.com

  
## Run Locally
You need `npm` and `node` installed in your local system. if you have not installed then first install `npm` and `node` in your local system.

After that Clone the project

```bash
  git clone https://github.com/the-macson/tic-tac-toe
```

Go to the project directory 

```bash
  cd .\tic-tac-toe
```
```bash
  npm start
```
## Contributing

Contributions are always welcome!

See [contributing](contributing.md) for ways to get started.

Please adhere to this project's `code of conduct`.

  
## License

[MIT](https://choosealicense.com/licenses/mit/)

  
## Screenshots
![Screenshot (46)](https://user-images.githubusercontent.com/71259159/130560632-15d05056-4331-43f7-b4a0-6c05c33275b9.png)

  
## Tech Stack

**Client:** React js, Bootstrap.

  
## 🚀 About Me
I' am a Full Stack Web developer and Currently Doing CSE Hons. and Enthusiasts in open source

  
## 🔗 Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/mukesh-kumar-macson/)

[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/the_macson)

  
## Lessons Learned
Using this Project I Learned how to use React js and how to use bootstrap, toastify, react icon and reactstrap in React js app.

I learned hooks, jsx, working of react components and many more I learned from this project

  
## Support

For support, email ak9991927952@gmail.com or join on my social media handle 

  
